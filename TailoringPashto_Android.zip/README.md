# د خیاطۍ مدیریت – پښتو Offline App

دا لومړۍ نمونه د Android Studio لپاره ده.
- پښتو UI
- Offline Room/SQLite database
- مشتری ثبتول
- د مشتریانو لست
- مشتری ړنګول

راتلونکې برخې: اندازې، فرمایشونه، قیمت/پیسې، پاتې حساب، Search، Backup او رسید.
