package com.tailoring.pashto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@Entity(tableName="customers")
data class Customer(@PrimaryKey(autoGenerate=true) val id:Int=0, val name:String, val phone:String, val address:String)

@Dao
interface CustomerDao {
 @Query("SELECT * FROM customers ORDER BY id DESC") fun all(): Flow<List<Customer>>
 @Insert suspend fun insert(c:Customer)
 @Delete suspend fun delete(c:Customer)
}

@Database(entities=[Customer::class], version=1, exportSchema=false)
abstract class AppDb: RoomDatabase() {
 abstract fun customerDao(): CustomerDao
 companion object { @Volatile private var INSTANCE:AppDb?=null
  fun get(context:android.content.Context)=INSTANCE?:synchronized(this){ INSTANCE?:Room.databaseBuilder(context.applicationContext,AppDb::class.java,"tailoring.db").build().also{INSTANCE=it}}
 }
}

class MainVM(private val dao:CustomerDao):ViewModel(){
 val customers=dao.all()
 fun add(n:String,p:String,a:String)=viewModelScope.launch{dao.insert(Customer(name=n,phone=p,address=a))}
 fun delete(c:Customer)=viewModelScope.launch{dao.delete(c)}
}

@Composable fun App(vm:MainVM){
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var address by remember{mutableStateOf("")}
 val list by vm.customers.collectAsState(initial=emptyList())
 MaterialTheme { Scaffold(topBar={TopAppBar(title={Text("د خیاطۍ مدیریت")})}){ pad->
  Column(Modifier.padding(pad).padding(16.dp)) {
   Text("نوی مشتری",style=MaterialTheme.typography.headlineSmall)
   Spacer(Modifier.height(8.dp))
   OutlinedTextField(name,{name=it},label={Text("د مشتری نوم")},modifier=Modifier.fillMaxWidth())
   OutlinedTextField(phone,{phone=it},label={Text("د موبایل شمېره")},modifier=Modifier.fillMaxWidth())
   OutlinedTextField(address,{address=it},label={Text("پته")},modifier=Modifier.fillMaxWidth())
   Spacer(Modifier.height(8.dp))
   Button(onClick={if(name.isNotBlank()){vm.add(name,phone,address);name="";phone="";address=""}},modifier=Modifier.fillMaxWidth()){Text("ثبتول")}
   Spacer(Modifier.height(18.dp)); Text("د مشتریانو لست",style=MaterialTheme.typography.headlineSmall)
   LazyColumn { items(list){ c->
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){
     Column(Modifier.weight(1f)){Text(c.name); if(c.phone.isNotBlank())Text("📞 ${c.phone}"); if(c.address.isNotBlank())Text("پته: ${c.address}")}
     TextButton(onClick={vm.delete(c)}){Text("ړنګول")}
    }}
   }}
  }
 }}
}

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val dao=AppDb.get(this).customerDao()
  setContent{App(MainVM(dao))}
 }
}
